import {BoxExtractType} from "../create_box/BoxExtractType";
export type BoxExtractFunction = (this: BoxExtractType, ...args: BoxExtractType[]) => BoxExtractType;
