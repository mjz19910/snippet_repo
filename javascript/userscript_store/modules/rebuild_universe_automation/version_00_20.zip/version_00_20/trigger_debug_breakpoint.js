export function trigger_debug_breakpoint() {
	debugger;
}
