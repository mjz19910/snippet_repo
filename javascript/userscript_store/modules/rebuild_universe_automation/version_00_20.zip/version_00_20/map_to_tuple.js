/**
 * @this {any[]}
 * @param {any} e
 * @param {number} i
 */
export function map_to_tuple(e, i) {
	return [e, this[i]];
}
