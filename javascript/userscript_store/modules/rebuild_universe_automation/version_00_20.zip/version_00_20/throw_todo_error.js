/**@returns {never} */
export function throw_todo_error() {
	throw new Error("TODO");
}
