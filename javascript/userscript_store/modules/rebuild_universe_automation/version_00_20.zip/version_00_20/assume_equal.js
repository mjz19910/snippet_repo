/**@type {<T, U extends T>(_v:T, x?:U)=>_v is U} */
export function assume_equal(_v, _q) {
	return true;
}
