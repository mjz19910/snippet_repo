export function throw_invalid_error() {
	return new Error("Invalid");
}
