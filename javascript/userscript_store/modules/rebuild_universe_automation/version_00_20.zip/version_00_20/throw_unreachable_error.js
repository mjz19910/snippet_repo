/**@returns {never} */
export function throw_unreachable_error() {
	throw new Error("Unreachable");
}
