/**@returns {never} */
export function not_reached() {
	throw new Error("Unreachable");
}
